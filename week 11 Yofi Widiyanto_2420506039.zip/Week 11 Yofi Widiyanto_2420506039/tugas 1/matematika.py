pi = 3.14159

def areacircle(radius):
  return pi * radius**2

def areasquare(side):
  return side**2